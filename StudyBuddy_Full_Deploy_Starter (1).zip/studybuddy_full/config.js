// Paste your Supabase project URL and publishable/anon key here.
// These are public browser settings, NOT service-role or secret API keys.
window.STUDYBUDDY_CONFIG = {
  SUPABASE_URL: "YOUR_SUPABASE_PROJECT_URL",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY"
};
